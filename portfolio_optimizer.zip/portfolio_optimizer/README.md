# Mean-Variance Portfolio Optimizer (SGX STI Multi-Asset Quant Case Study)
## Project Overview
Self-directed quantitative finance project built for Singapore quant trading & asset management internship portfolios. Implements Markowitz mean-variance constrained quadratic optimization in Python to construct risk-adjusted portfolios using SGX STI blue-chip equities + S&P500 SPY ETF.

## Core Finance & Math Concepts
1. Daily log return time-series transformation for asset price modeling
2. Annualized covariance matrix to quantify cross-asset risk co-movement
3. Constrained convex optimization (no short-selling, full capital allocation constraint)
4. Sharpe Ratio: standardized risk-adjusted return metric for portfolio comparison

## Tools & Python Libraries
Data: yfinance
Numerical Computing: NumPy, Pandas
Optimization Solver: CVXPY
Visualization: Matplotlib

## Asset Universe
8 Assets (SGX STI Large-Cap + US Global ETF):
D05.SI (DBS Bank), U11.SI (UOB), O39.SI (OCBC), C38U.SI (CapitaLand CCT),
G13.SI (Genting Singapore), Z74.SI (Singtel), STI.SI (STI Index ETF)
Data Period: 5 years daily adjusted close prices (2021–2026)

## Portfolio Strategies Implemented
1. Equal Weight Portfolio: Simple naive benchmark allocation
2. Minimum Variance Portfolio: Optimized to minimize total portfolio volatility
3. Maximum Sharpe Ratio Portfolio: Optimized for highest reward per unit risk

## Key Empirical Results 
- Equal Weight Portfolio: Return = 11.57%, Volatility = 16.94%, Sharpe Ratio = 0.565
- Minimum Variance Portfolio: Return = 10.46%, Volatility = 15.65%, Sharpe Ratio = 0.540
- Max Sharpe Portfolio: Return = 19.65%, Volatility = 19.45%, Sharpe Ratio = 0.907

## Project Visual Outputs
1. Cumulative 5-Year Portfolio Performance Curve: Tracks $1 initial wealth across all 3 strategies
2. Mean-Variance Efficient Frontier: Plots all feasible risk/return portfolios, highlights optimized allocations
### Visual 1: Mean-Variance Efficient Frontier
![Efficient Frontier Plot](plots/efficient_frontier.png)
### Visual 2: Cumulative Portfolio Performance
![Portfolio Return Curve](plots/portfolio_performance.png)


## How to Reproduce Results Locally
1. Install dependencies in terminal:
```bash
pip install yfinance numpy pandas matplotlib cvxpy scipy